//
//  AuthInteractor.swift
//  NeSwarm
//
//  Created by Admin on 20.10.2022.
//

import Foundation

class AuthInteractor: AuthInteractorProtocol {
    var delegate: AuthInteractorDelegateProtocol?
    

}
