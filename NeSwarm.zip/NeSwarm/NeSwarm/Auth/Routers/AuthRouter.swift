//
//  AuthRouter.swift
//  NeSwarm
//
//  Created by Admin on 20.10.2022.
//

import Foundation
import UIKit

class AuthRouter: AuthRouterProtocol {
    weak var viewController: UIViewController?
    
}
